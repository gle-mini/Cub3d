from PIL import Image

def convert_to_xpm(image_path, output_path):
    # Open the image using Pillow
    image = Image.open(image_path)

    # Convert the image to a list of RGB pixel values
    rgb_pixels = list(image.convert("RGB").getdata())

    # Determine the image dimensions
    width, height = image.size

    # Create the XPM header
    xpm_data = ['/* XPM */',
                'static char * image_xpm[] = {',
                f'"{width} {height} 3 1",']

    # Define the color table
    colors = {'#000000': 'c',  # black
              '#ffffff': 'w',  # white
              '#ff0000': 'r'}  # red

    # Create the XPM pixel data
    for y in range(height):
        row = ''
        for x in range(width):
            pixel = rgb_pixels[y * width + x]
            color = '#{:02x}{:02x}{:02x}'.format(*pixel)
            char = colors.get(color, ' ')
            row += char
        xpm_data.append(f'"{row}",')

    # Close the XPM data
    xpm_data.append('};')

    # Save the XPM data to a file
    with open(output_path, 'w') as output_file:
        output_file.write('\n'.join(xpm_data))

# Specify the path to the input image
input_image_path = 'mchassig.jpg'

# Specify the path to save the XPM file
output_xpm_path = 'mchassig.xpm'

# Convert the image to XPM format
convert_to_xpm(input_image_path, output_xpm_path)

